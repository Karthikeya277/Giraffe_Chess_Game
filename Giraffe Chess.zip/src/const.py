WIDTH = 640
HEIGHT  = 800

ROWS = 10
COLS = 8
SQSIZE = WIDTH // COLS

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
# Colors
LIGHT_GRAY = (200, 200, 200)
BOARD_COLOR = (0, 128, 0)  # Green color for the chessboard
SQUARE_COLORS = [(255, 206, 158), (209, 139, 71)]  # Light and dark square colors

# Board dimensions
BOARD_WIDTH = 640 # Width of the chessboard
BOARD_HEIGHT = 800  # Height of the chessboard

