class GiraffeChessBoard:
    def __init__(self):
        self.rows = 10
        self.columns = 8
        self.piece_positions = {}
        self.last_positions = {}  # Store last positions of pieces
        self.white_pieces = ['white_rook1', 'white_rook2', 'white_knight1', 'white_knight2', 'white_bishop1',
                             'white_bishop2', 'white_queen', 'white_king', 'white_pawn1', 'white_pawn2',
                             'white_pawn3', 'white_pawn4', 'white_pawn5', 'white_pawn6', 'white_pawn7',
                             'white_pawn8', 'white_giraffe1', 'white_giraffe2']
        self.black_pieces = ['black_rook1', 'black_rook2', 'black_knight1', 'black_knight2', 'black_bishop1',
                             'black_bishop2', 'black_queen', 'black_king', 'black_pawn1', 'black_pawn2',
                             'black_pawn3', 'black_pawn4', 'black_pawn5', 'black_pawn6', 'black_pawn7',
                             'black_pawn8', 'black_giraffe1', 'black_giraffe2']

        # Define starting positions for pieces
        starting_positions = {
            # White pieces
            'white_rook1': ('a', 2), 'white_rook2': ('h', 2),
            'white_knight1': ('b', 2), 'white_knight2': ('g', 2),
            'white_bishop1': ('c', 2), 'white_bishop2': ('f', 2),
            'white_queen': ('d', 2), 'white_king': ('e', 2),
            'white_pawn1': ('a', 3), 'white_pawn2': ('b', 3),
            'white_pawn3': ('c', 3), 'white_pawn4': ('d', 3),
            'white_pawn5': ('e', 3), 'white_pawn6': ('f', 3),
            'white_pawn7': ('g', 3), 'white_pawn8': ('h', 3),
            'white_giraffe1': ('d', 1), 'white_giraffe2': ('e', 1),
            # Black pieces
            'black_rook1': ('a', 9), 'black_rook2': ('h', 9),
            'black_knight1': ('b', 9), 'black_knight2': ('g', 9),
            'black_bishop1': ('c', 9), 'black_bishop2': ('f', 9),
            'black_queen': ('d', 9), 'black_king': ('e', 9),
            'black_pawn1': ('a', 8), 'black_pawn2': ('b', 8),
            'black_pawn3': ('c', 8), 'black_pawn4': ('d', 8),
            'black_pawn5': ('e', 8), 'black_pawn6': ('f', 8),
            'black_pawn7': ('g', 8), 'black_pawn8': ('h', 8),
            'black_giraffe1': ('d', 10), 'black_giraffe2': ('e', 10)
        }

        # Initialize piece positions and last positions
        for piece, pos in starting_positions.items():
            self.piece_positions[piece] = pos
            self.last_positions[piece] = pos

    def is_valid_position(self, row, col):
        return 'a' <= row <= 'h' and 1 <= col <= 8

    def is_obstacle_present(self, row, col):
        return any(pos == (row, col) for pos in self.piece_positions.values())

    def generate_moves(self, piece, row, col, is_white_turn):
        possible_moves = []

        # Pawn moves
        if piece.startswith('white_pawn'):
            direction = 1
            start_row = 2
            enemy_start_row = 7
        elif piece.startswith('black_pawn'):
            direction = -1
            start_row = 7
            enemy_start_row = 2
        else:
            direction = None

        if direction is not None:
            if self.is_valid_position(row, col + direction) and not self.is_obstacle_present(row, col + direction):
                possible_moves.append((row, col + direction))
            if col == start_row and self.is_valid_position(row, col + 2 * direction) \
                    and not self.is_obstacle_present(row, col + 2 * direction):
                possible_moves.append((row, col + 2 * direction))
            for i in [-1, 1]:
                if self.is_valid_position(chr(ord(row) + i), col + direction) \
                        and (chr(ord(row) + i), col + direction) in self.piece_positions.values():
                    possible_moves.append((chr(ord(row) + i), col + direction))

        # Giraffe moves
        if piece.startswith('white_giraffe') or piece.startswith('black_giraffe'):
            col_int = ord(row) - ord('a')  # Convert column letter to numerical value
            row_int = col - 1  # No need to convert row since it's already numerical
            moves = [(row_int + 1, col_int + 3), (row_int + 3, col_int + 1), (row_int - 1, col_int + 3),
                     (row_int - 3, col_int + 1),
                     (row_int + 1, col_int - 3), (row_int + 3, col_int - 1), (row_int - 1, col_int - 3),
                     (row_int - 3, col_int - 1)]
            for move in moves:
                if self.is_valid_position(chr(ord('a') + move[1]), move[0] + 1):
                    if not self.is_obstacle_present(chr(ord('a') + move[1]), move[0] + 1) or \
                            (chr(ord('a') + move[1]), move[0] + 1) in [
                                v for k, v in self.piece_positions.items() if
                                (is_white_turn and k.startswith('black')) or
                                (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((chr(ord('a') + move[1]), move[0] + 1))

        # Knight moves
        if piece.startswith('white_knight') or piece.startswith('black_knight'):
            moves = [(2, 1), (2, -1), (-2, 1), (-2, -1), (1, 2), (1, -2), (-1, 2), (-1, -2)]
            for move in moves:
                new_row = chr(ord(row) + move[0])
                new_col = col + move[1]
                if self.is_valid_position(new_row, new_col):
                    if not self.is_obstacle_present(new_row, new_col) or \
                            (new_row, new_col) in [v for k, v in self.piece_positions.items() if
                                                       (is_white_turn and k.startswith('black')) or
                                                       (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((new_row, new_col))

        # King moves
        if piece.startswith('white_king') or piece.startswith('black_king'):
            moves = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)]
            for move in moves:
                new_row = chr(ord(row) + move[0])
                new_col = col + move[1]
                if self.is_valid_position(new_row, new_col):
                    if not self.is_obstacle_present(new_row, new_col) or \
                            (new_row, new_col) in [v for k, v in self.piece_positions.items() if
                                                       (is_white_turn and k.startswith('black')) or
                                                       (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((new_row, new_col))

        # Queen moves
        if piece.startswith('white_queen') or piece.startswith('black_queen'):
            # Rook-like moves
            for i in range(1, 8):
                if self.is_valid_position(chr(ord(row) + i), col):
                    if not self.is_obstacle_present(chr(ord(row) + i), col) or \
                            (chr(ord(row) + i), col) in [v for k, v in self.piece_positions.items() if
                                                             (is_white_turn and k.startswith('black')) or
                                                             (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((chr(ord(row) + i), col))
                    if self.is_obstacle_present(chr(ord(row) + i), col):
                        break
            for i in range(1, 8):
                if self.is_valid_position(chr(ord(row) - i), col):
                    if not self.is_obstacle_present(chr(ord(row) - i), col) or \
                            (chr(ord(row) - i), col) in [v for k, v in self.piece_positions.items() if
                                                             (is_white_turn and k.startswith('black')) or
                                                             (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((chr(ord(row) - i), col))
                    if self.is_obstacle_present(chr(ord(row) - i), col):
                        break
            for i in range(1, 8):
                if self.is_valid_position(row, col + i):
                    if not self.is_obstacle_present(row, col + i) or \
                            (row, col + i) in [v for k, v in self.piece_positions.items() if
                                               (is_white_turn and k.startswith('black')) or
                                               (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((row, col + i))
                    if self.is_obstacle_present(row, col + i):
                        break
            for i in range(1, 8):
                if self.is_valid_position(row, col - i):
                    if not self.is_obstacle_present(row, col - i) or \
                            (row, col - i) in [v for k, v in self.piece_positions.items() if
                                               (is_white_turn and k.startswith('black')) or
                                               (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((row, col - i))
                    if self.is_obstacle_present(row, col - i):
                        break

            # Bishop-like moves
            for i in range(1, 8):
                if self.is_valid_position(chr(ord(row) + i), col + i):
                    if not self.is_obstacle_present(chr(ord(row) + i), col + i) or \
                            (chr(ord(row) + i), col + i) in [v for k, v in self.piece_positions.items() if
                                                             (is_white_turn and k.startswith('black')) or
                                                             (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((chr(ord(row) + i), col + i))
                    if self.is_obstacle_present(chr(ord(row) + i), col + i):
                        break
            for i in range(1, 8):
                if self.is_valid_position(chr(ord(row) + i), col - i):
                    if not self.is_obstacle_present(chr(ord(row) + i), col - i) or \
                            (chr(ord(row) + i), col - i) in [v for k, v in self.piece_positions.items() if
                                                             (is_white_turn and k.startswith('black')) or
                                                             (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((chr(ord(row) + i), col - i))
                    if self.is_obstacle_present(chr(ord(row) + i), col - i):
                        break
            for i in range(1, 8):
                if self.is_valid_position(chr(ord(row) - i), col + i):
                    if not self.is_obstacle_present(chr(ord(row) - i), col + i) or \
                            (chr(ord(row) - i), col + i) in [v for k, v in self.piece_positions.items() if
                                                             (is_white_turn and k.startswith('black')) or
                                                             (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((chr(ord(row) - i), col + i))
                    if self.is_obstacle_present(chr(ord(row) - i), col + i):
                        break
            for i in range(1, 8):
                if self.is_valid_position(chr(ord(row) - i), col - i):
                    if not self.is_obstacle_present(chr(ord(row) - i), col - i) or \
                            (chr(ord(row) - i), col - i) in [v for k, v in self.piece_positions.items() if
                                                             (is_white_turn and k.startswith('black')) or
                                                             (not is_white_turn and k.startswith('white'))]:
                        possible_moves.append((chr(ord(row) - i), col - i))
                    if self.is_obstacle_present(chr(ord(row) - i), col - i):
                        break

        return possible_moves

    def all_possible_moves(self, is_white_turn):
        all_moves = []
        for piece, (row, col) in self.piece_positions.items():
            if (is_white_turn and piece.startswith('white')) or (not is_white_turn and piece.startswith('black')):
                all_moves += self.generate_moves(piece, row, col, is_white_turn)
        return all_moves

    def print_board(self):
        for r in range(1, self.rows + 1):
            for c in range(1, self.columns + 1):
                piece_found = False
                for piece, (row, col) in self.piece_positions.items():
                    if r == col and chr(ord('a') + c - 1) == row:
                        print(piece, end='\t')
                        piece_found = True
                        break
                if not piece_found:
                    print("-", end='\t')
            print()

# Example usage:
board = GiraffeChessBoard()

# Print initial positions
print("Initial Positions:")
board.print_board()

# White turn
is_white_turn = True
while True:
    piece_name = input("Enter piece name: ")
    if piece_name in board.piece_positions.keys() and (is_white_turn and piece_name.startswith('white')) or \
            (not is_white_turn and piece_name.startswith('black')):
        possible_moves = board.generate_moves(piece_name, *board.piece_positions[piece_name], is_white_turn)
        print("Possible moves:", possible_moves)
        break
    else:
        print("Invalid piece name. Try again.")

# Black turn
is_white_turn = False
while True:
    piece_name = input("Enter piece name: ")
    if piece_name in board.piece_positions.keys() and (is_white_turn and piece_name.startswith('white')) or \
            (not is_white_turn and piece_name.startswith('black')):
        possible_moves = board.generate_moves(piece_name, *board.piece_positions[piece_name], is_white_turn)
        print("Possible moves:", possible_moves)
        break
    else:
        print("Invalid piece name. Try again.")
