import os
import pygame
import sys

class WelcomePage: 
    def __init__(self):
        
        pygame.init()
        # Get the display info to set the screen size
        self.screen_info = pygame.display.Info()
        self.screen_width = self.screen_info.current_w
        self.screen_height = self.screen_info.current_h
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height), pygame.FULLSCREEN)
        pygame.display.set_caption('Welcome to Giraffe Chess')
        self.clock = pygame.time.Clock()
        self.background = pygame.image.load(os.path.join('C:\\Users\\karthi\\Downloads\\Game_project\\assets\\images\\welcome_background.png')).convert()
        # Scale the background image to fit the screen
        self.background = pygame.transform.scale(self.background, (self.screen_width, self.screen_height))
        self.logo = pygame.image.load(os.path.join('C:\\Users\\karthi\\Downloads\\Game_project\\assets\\images\\giraffe_logo_image.png')).convert_alpha()
        # Calculate the position of the logo to center it
        self.logo_rect = self.logo.get_rect(center=(self.screen_width // 2, self.screen_height // 4))
        self.start_button = pygame.Rect(self.screen_width // 3, self.screen_height // 2, self.screen_width // 3, self.screen_height // 10)
        self.start_button_color = (50, 205, 50)  # Green color for the button
        self.font = pygame.font.Font(None, self.screen_height // 15)
        self.start_text = self.font.render('Start', True, (255, 255, 255))

    def run(self):
        running = True
        while running:
            self.screen.blit(self.background, (0, 0))
            self.screen.blit(self.logo, self.logo_rect)
            pygame.draw.rect(self.screen, self.start_button_color, self.start_button)
            # Calculate the position of the start text to center it on the button
            text_rect = self.start_text.get_rect(center=self.start_button.center)
            self.screen.blit(self.start_text, text_rect)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.start_button.collidepoint(event.pos):
                        running = False

            pygame.display.flip()
            self.clock.tick(60)  # Cap the frame rate to 60 FPS

        return True  # Signal to start the game

if __name__ == '__main__':
    welcome_page = WelcomePage()
    start_game = welcome_page.run()
    if start_game:
        # Start the main game loop
        from main import Main
        main = Main()
        main.mainloop()
