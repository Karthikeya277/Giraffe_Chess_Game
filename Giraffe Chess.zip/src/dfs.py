class GiraffeChessBoard:
    def __init__(self):
        self.rows = 10
        self.columns = 8

    def is_valid_position(self, row, col):
        return 0 <= row < self.rows and 0 <= col < self.columns

    def dfs(self, piece, row, col, visited=None):
        if visited is None:
            visited = set()

        visited.add((row, col))

        possible_moves = self.generate_moves(piece, row, col)
        for move_row, move_col in possible_moves:
            if (move_row, move_col) not in visited:
                self.dfs(piece, move_row, move_col, visited)

        return visited

    def generate_moves(self, piece, row, col):
        possible_moves = []

        # King moves
        if piece == 'King':
            directions = [(1, 0), (-1, 0), (0, 1), (0, -1),
                          (1, 1), (-1, 1), (1, -1), (-1, -1)]
            for dr, dc in directions:
                if self.is_valid_position(row + dr, col + dc):
                    possible_moves.append((row + dr, col + dc))

        # Queen moves
        elif piece == 'Queen':
            directions = [(1, 0), (-1, 0), (0, 1), (0, -1),
                          (1, 1), (-1, 1), (1, -1), (-1, -1)]
            for dr, dc in directions:
                r, c = row, col
                while self.is_valid_position(r + dr, c + dc):
                    r, c = r + dr, c + dc
                    possible_moves.append((r, c))

        # Bishop moves
        elif piece == 'Bishop':
            directions = [(1, 1), (-1, 1), (1, -1), (-1, -1)]
            for dr, dc in directions:
                r, c = row, col
                while self.is_valid_position(r + dr, c + dc):
                    r, c = r + dr, c + dc
                    possible_moves.append((r, c))

        # Rook moves
        elif piece == 'Rook':
            directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
            for dr, dc in directions:
                r, c = row, col
                while self.is_valid_position(r + dr, c + dc):
                    r, c = r + dr, c + dc
                    possible_moves.append((r, c))

        # Knight moves
        elif piece == 'Knight':
            moves = [(2, 1), (1, 2), (-2, 1), (-1, 2),
                     (-2, -1), (-1, -2), (2, -1), (1, -2)]
            for dr, dc in moves:
                if self.is_valid_position(row + dr, col + dc):
                    possible_moves.append((row + dr, col + dc))

        # Giraffe moves
        elif piece == 'Giraffe':
            moves = [(3, 1), (1, 3), (-3, 1), (-1, 3),
                     (-3, -1), (-1, -3), (3, -1), (1, -3)]
            for dr, dc in moves:
                if self.is_valid_position(row + dr, col + dc):
                    possible_moves.append((row + dr, col + dc))

        # Pawn moves
        elif piece == 'Pawn':
            # Assuming a pawn can move one step forward
            if self.is_valid_position(row + 1, col):
                possible_moves.append((row + 1, col))
            # Assuming a pawn can move one step backward
            if self.is_valid_position(row - 1, col):
                possible_moves.append((row - 1, col))

        return possible_moves

    def all_possible_moves(self, piece, row, col):
        return self.generate_moves(piece, row, col)


# Example usage:
board = GiraffeChessBoard()

# Get user input for piece and position
piece = input("Enter piece name: ")
row, col = map(int, input("Enter row and column of the position (0-9, 0-7): ").split())

# Get all possible moves for the given piece at the specified position
possible_moves = board.all_possible_moves(piece, row, col)
print(f"All possible moves for {piece} at position ({row}, {col}): {possible_moves}")
