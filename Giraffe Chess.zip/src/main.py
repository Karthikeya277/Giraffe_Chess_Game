import pygame
import sys

from const import *
from game import Game
from dragger import Dragger
from square import Square
from move import Move

class Main:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption('Giraffe_Chess')
        self.game = Game()
        self.winner = None
        self.win_time =  None
        
        # Initialize your game variables
        
    def mainloop(self):
        screen = self.screen
        game = self.game
        dragger = self.game.dragger
        board = self.game.board
        move = None
        while True:
         
            game.show_bg(screen)
            game.show_moves(screen)
            game.show_last_move(screen)
            game.show_pieces(screen)

            game.show_hover(screen)

            if dragger.dragging:
                dragger.update_bilt(screen)

            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    dragger.updated_mouse(event.pos)
                    clicked_row = dragger.mouseY // SQSIZE
                    clicked_col = dragger.mouseX // SQSIZE
                    
                    #if clicked square has piece
                    if board.squares[clicked_row][clicked_col].has_piece():
                        piece = board.squares[clicked_row][clicked_col].piece
                        # valid piece(color).?
                        if piece.color == game.next_player:
                            board.calc_moves(piece, clicked_row, clicked_col, bool=True)
                            dragger.save_initial(event.pos)
                            dragger.drag_piece(piece)
                            
                            # show methods
                            game.show_bg(screen)
                            game.show_last_move(screen)
                            game.show_moves(screen)
                            game.show_pieces(screen)
                    #mouse motion
                elif event.type == pygame.MOUSEMOTION:
                    motion_row = event.pos[1] // SQSIZE
                    motion_col = event.pos[0] // SQSIZE

                    game.set_hover(motion_row, motion_col)


                    if dragger.dragging:
                        dragger.updated_mouse(event.pos)
                        #show
                        game.show_bg(screen)
                        game.show_last_move(screen)
                        game.show_moves(screen)
                        game.show_pieces(screen)
                        game.show_hover(screen)
                        dragger.update_bilt(screen)
                   #click release
                    
                elif event.type == pygame.MOUSEBUTTONUP:
    # Click release
                    if dragger.dragging:
                       dragger.updated_mouse(event.pos)

                       released_row = dragger.mouseY // SQSIZE
                       released_col = dragger.mouseX // SQSIZE
         
        # Create possible move
                       initial = Square(dragger.initial_row, dragger.initial_col)
                       final  = Square(released_row, released_col)
                       move = Move(initial, final)

        # Check if it's a valid move
                       if board.valid_move(dragger.piece, move):
                         captured = board.squares[released_row][released_col].has_piece()

                         board.move(dragger.piece, move)
                         board.set_true_en_passant(dragger.piece)
                         #sounds
                         game.play_sound(captured)
                         opponent_color = 'black' if game.next_player == 'white' else 'white'
                         winner = game.check_winner()
                         if winner:
                          print(f"Player {winner} wins!")
                          game.reset()
                        
                          game = self.game
                          dragger = self.game.dragger
                          board = self.game.board
                    
            # Show methods
                         game.show_bg(screen)
                         game.show_moves(screen)
                         
                         game.show_pieces(screen)
                         game.next_turn()
                         
                         
           

                       dragger.undrag_piece()

               

                elif event.type == pygame.KEYDOWN:
                    #changing themes
                    if event.key == pygame.K_t:
                        game.change_theme()
                    
                    if event.key == pygame.K_r:
                        game.reset()
                        
                        game = self.game
                        dragger = self.game.dragger
                        board = self.game.board
                    if event.key == pygame.K_u:
                        game.undo_move()

                elif event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            pygame.display.update()
    
            
           

main = Main()
main.mainloop()