import tkinter as tk
from tkinter import messagebox
from board import Board

class Main(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Giraffe Chess")
        self.geometry("700x390")

        # Initialize the board
        self.board = Board()

        # Add widgets
        self.canvas = tk.Canvas(self, width=700, height=390)
        self.canvas.pack()

        # Your other GUI elements...

    def check_winner(self):
        if self.board.is_player_stuck("white"):
            messagebox.showinfo("Game Over", "Black player wins!")
            self.quit()
        elif self.board.is_player_stuck("black"):
            messagebox.showinfo("Game Over", "White player wins!")
            self.quit()
        # Add conditions for other win scenarios if needed

    # Your other methods...

if __name__ == "__main__":
    main = Main()
    main.mainloop()
